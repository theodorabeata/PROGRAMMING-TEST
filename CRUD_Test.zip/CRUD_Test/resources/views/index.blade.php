<!DOCTYPE html>
<html>
<head>CRUD Test</head>
<body>
 
	<h3>List Of Books</h3>
 
	<a href="/books/tambah"> + Add New Books</a>
	
	<br/>
	<br/>
 
	<table border="1">
		<tr>
			<th>Title</th>
			<th>Author</th>
			<th>Date Published</th>
			<th>Number of Pages</th>
			<th>Type of Book</th>
            <th>Option</th>
		</tr>
		@foreach($books as $b)
		<tr>
			<td>{{ $b->books_title }}</td>
			<td>{{ $b->books_author }}</td>
			<td>{{ $b->books_date }}</td>
			<td>{{ $b->books_numpage }}</td>
            <td>{{ $b->books_type }}</td>
			<td>
				<a href="/books/edit/{{ $b->books_id }}">Edit</a>
				|
				<a href="/books/hapus/{{ $b->books_id }}">Hapus</a>
			</td>
		</tr>
		@endforeach
	</table>
 
 
</body>
</html>
