<!DOCTYPE html>
<html>
<head>
	<title>CRUD Test</title>
</head>
<body>
 
	<h3>List Of Books</h3>
 
	<a href="/books"> Kembali</a>
	
	<br/>
	<br/>
 
	<form action="/books/store" method="post">
		{{ csrf_field() }}
		Title <input type="text" name="title" required="required"> <br/>
		Author <input type="text" name="author" required="required"> <br/>
		Date Published <input type="date" name="date" required="required"> <br/>
		Number of Pages <input type="number" name="numpage" required="required"> <br/>
        Type of Books <input type="text" name="type" required="required"><br/>
		<input type="submit" value="Simpan Data">
	</form>
 
</body>
</html>