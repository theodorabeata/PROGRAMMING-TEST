<!DOCTYPE html>
<html>
<head>
	<title>CRUD Test</title>
</head>
<body>
 
	<h3>Edit List Of Books</h3>
 
	<a href="/books"> Kembali</a>
	
	<br/>
	<br/>
 
	@foreach($books as $b)
	<form action="/books/update" method="post">
		{{ csrf_field() }}
		<input type="hidden" name="id" value="{{ $b->books_id }}"> <br/>
        Title <input type="text" name="title" required="required" value="{{ $b->books_title }}"> <br/>
		Author <input type="text" name="author" required="required" value="{{ $b->books_author }}"> <br/>
		Date Published <input type="date" name="date" required="required" value="{{ $b->books_date }}"> <br/>
		Number of Pages <input type="number" name="numpage" required="required" value="{{ $b->books_numpage }}"> <br/>
        Type of Books <input type="text" name="type" required="required" value="{{ $b->books_type }}"> <br/>
		<input type="submit" value="Simpan Data">
	</form>
	@endforeach
		
 
</body>
</html>