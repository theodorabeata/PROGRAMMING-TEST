<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Route CRUD Books
Route::get('/books','BooksController@index');

//Route Add Books
Route::get('/books/tambah','BooksController@tambah');
Route::post('/books/store','BooksController@store');

//Route Edit Books
Route::get('/books/edit{id}','BooksController@edit');
Route::post('/books/update','BooksController@update');

Route::get('/books/hapus/{id}','BooksController@hapus');