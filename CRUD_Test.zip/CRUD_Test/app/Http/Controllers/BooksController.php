<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BooksController extends Controller
{
    public function index()
    {
        //mengambil data dari table books
        $books = DB::table('books')->get();

        //mengirim data list of books ke view index
        return view('index',['books' => $books]);
    }

    public function tambah()
    {
        //memanggil view tambah
        return view('tambah');
    }

    public function store(Request $request)
    {
        $date = date('Y-m-d');
        $date = $request-> date;
        // insert data ke table list of books
	    DB::table('books')->insert([
		    'books_title' => $request->title,
		    'books_author' => $request->author,
		    'books_date' => $date,
            'books_numpage' => $request->numpage,
            'books_type' => $request->type
	    ]);
	    // alihkan halaman ke halaman utama
	    return redirect('/books');
    }

    // method untuk edit daftar buku
    public function edit($id)
    {
	    // mengambil data books berdasarkan id yang dipilih
	    $books = DB::table('books')->where('books_id',$id)->get();
	    // passing data books yang didapat ke view edit.blade.php
	    return view('edit',['books' => $books]);
 
    }

    // update data books
    public function update(Request $request)
    {
        $date = date('Y-m-d');
        $date = $request-> date;
	    // update data books
	    DB::table('books')->where('books_id',$request->id)->update([
		    'books_title' => $request->title,
		    'books_author' => $request->author,
		    'books_date' => $date,
            'books_numpage' => $request->numpage,
            'books_type' => $request->type
	    ]);
	    // alihkan halaman ke halaman pegawai
	    return redirect('/books');
    }

    // method untuk hapus data list of books
    public function hapus($id)
    {
	    // menghapus data list of books
	    DB::table('books')->where('books_id',$id)->delete();
		
	    // alihkan halaman ke halaman books
	return redirect('/books');
    }

}
