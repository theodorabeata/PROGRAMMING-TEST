class Ted {

 public static void main(String[] args) {
  int selfnum[] = new int[10001];
  
  int i;
  int j=1;
  int count=0;

  for(i=0;i<=10000;i++)
  
   if(i<9)
    selfnum[i] = (i+1) + (i+1)%10;
   else if(i<100)
    selfnum[i] = i + i/10 + i%10;
   else if(i<1000)
    selfnum[i] = i + i/100 + (i%100)/10 + i%10;
   else if(i<=10000)
    selfnum[i] = i + i/1000 + (i%1000)/100 +((i%1000)%100)/10+ i%10;
  
  do{
   for(i=0;i<10001;i++)
    if(j==selfnum[i]) {
     count ++; break;
    }
   if(count==0)
    System.out.println(j);
   count =0;
   j++;
  }while(j<=10000);
 }
}
